package com.company;

public interface CrossHairListener {
    void onShotsFired(int x, int y);
}
